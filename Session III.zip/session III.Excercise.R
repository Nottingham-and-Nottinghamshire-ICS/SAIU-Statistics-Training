#============================================================================
# packages
if (!require("epitools")){ install.packages("epitools")}
if (!require("dplyr")){ install.packages("dplyr")}
if (!require("ggplot2")){ install.packages("ggplot2")}
if (!require("summarytools")){ install.packages("summarytools")}

if (!require("readr")){ install.packages("readr")}
if (!require("DescTools")){ install.packages("DescTools")} # Cochran-Armitage test for trend
if (!require("gmodels")){ install.packages("gmodels")}


library(readr)
library(ggplot2)
library(epitools)
library(summarytools)
library(DescTools)
library(gmodels)
library(stargazer)
library(readxl)


#==========================================================================
# CATEGORICAL DATA
#=============================================================================

data <- read_csv("subset_dataset.csv")

#data <- read_csv("sample_data3.csv")

#============================================================================
#  Task 1 : You are going to explore the association between heart failure and current smoking status

data <- data  %>% filter(sex == "Male"| sex == "Female")

names(data)

data <- data %>% 
  mutate(smoker = case_when( 
    currentsmoker ==  1 ~ "Smoker",
    currentsmoker  == 0 ~ "Non Smoker"))%>% 
  mutate(hf2 = case_when( 
    hf ==  1 ~ "With HF",
    hf  == 0 ~ "Without HF")) %>%  
mutate(chd2 = case_when( 
  chd ==  1 ~ "With CHD",
  chd  == 0 ~ "Without CHD"))  %>% 
  mutate(livesalone = case_when( 
    livesalone ==  1 ~ "Yes",
    livesalone  == 0 ~ "No"))  %>% 
  mutate(carehome = case_when( 
    carehome ==  1 ~ "Yes",
    carehome  == 0 ~ "No")) %>% 
  mutate(alcoholmisuse = case_when( 
    alcoholmisuse ==  1 ~ "Yes",
    alcoholmisuse  == 0 ~ "No"))
#=================================================================================
# PROPORTIONS
#=================================================================================
# visualize the  number and proportions with/without hf by smoking status (yes no)

hf_prop <- data  %>%
  group_by(smoker) %>%
  group_by(hf2, .add= "TRUE")%>%
  summarize(N = n()) %>%   
  mutate(freq = N / sum(N),
         pct = round((freq*100), 2),
         pct = paste0(pct,"%"))
hf_prop

# quick visualization
ggplot(hf_prop, aes(x= smoker, y=pct, fill = smoker))+
  geom_bar(stat = "identity",width = 0.5) + facet_wrap( ~ hf2)

# The mosaic plot is another graphical technique for showing the association between two categorical variables

# create a contingency table for hf by smoking status using the table function (first parameter is row, 2nd parameter is column(outcome) variable)

# replace var = smoker, var2 = hf

table <- table(data$var1, data$var2)

# insert values to replace the following variables

# value1= non smokers without hf
# value2 = smokers without hf
# value3= non smokers with hf
# value4 = smokers with hf

association.table <- data.frame("No HF"=c(value1,value2),HF=c(value3,value4), row.names=c("Non-Smokers","Smokers"))


mosaicplot(association.table, color = c("darkred", "gold"), xlab ="Smoking status", ylab = "Proportion")



# calculate percentages
table2 <- round(prop.table((table), margin=1) *100,2) # for row marginals

table2
# prop.table((table), margin=2)  # for columns marginals

data$hf <- as.factor(data$hf)

data$smoker <- as.factor(data$smoker)

# replace va1= smoker, var2 = hf

summarytools::ctable(data$var1, data$var2,prop = 'n', totals = TRUE)

# The prop test simply test whether the proportions are different
# it doesn't provide any information about the direction, i.e which one is higher or lower


# syntax below 
prop.test(x = c(non-smokers_hf, smokers_hf), n = c(Total_non_smokers, Total_Smokers))


# replace non-smokers_hf, smokers_hf, Total_non_smokers, Total_Smokers accordingly

res <- prop.test(x = c(non-smokers_hf, smokers_hf), n = c(Total_non_smokers, Total_Smokers))
# Printing the results
res

# printing the p-value
res$p.value

# printing the mean
res$estimate

#printing the confidence interval
res$conf.int

# The test returns the following important statistics - pearson chi-square test statistics, p value, 95% CI

# if you want to test whether the observed proportion of smokers with hf is less than the observed proportion of non -smokers with hf, type this:


# complete the prop.test function by inserting the values and interpret your results
prop.test(x = c(62, non-smokers_hf), n = c(Total_Smokers, 44181),
          alternative = "less")

# if you want to test whether the observed proportion of smokers with hf is greater than the observed proportion of non smokers with hf, type this:

# complete the prop.test function by inserting the values and interpret your results
prop.test(x = c(hf_smoker, 544), n = c(5817, Total_non_smokers),
          alternative = "greater")


#================================================================================
# ODDS RATIO
#===============================================================================

# One of the ways to measure the strength of the association between two categorical variables is using odds ratio.

# To obtain crude odds ratio, either a 2x2 table can be used or a one predictor logistic regression model can be fitted
# or use the command fisher.test()


# methods 1 : Using the contingency table to extract the elements individually

# specify outcome in 2nd part of the table parameter, in this case, chd

# replace va1= smoker, var2= hf
table <- table(data$var1, data$var2)

table 

#summarytools::ctable(data$sex, data$chd,prop = 'r',totals=TRUE)

a <- table[2, 1]
b <- table[2, 2]
c <- table[1,1]
d <- table[1,2]

# Calculate the odds smoker to non - smoker
odds_ratio <- (b * c) / (a * d) 

# Print the odds ratio
print(odds_ratio)

# methods 2: Using a single predictor model

# Fit model

# replace va1= smoker, var2= hf
fit1 <- glm(var2 ~ var1, data=data, family=binomial)
summary(fit1)

coef(fit1) %>% exp()

# Provide some interpretation to your results

confint(fit1) %>% exp()

# method 3. Using fisher test

fisher_test = fisher.test(table)
fisher_test


# Chi-square test of independence in R
# The chi-square test evaluates whether there is a significant association between the categories of the two variables.

# replace var1 = hf

Chi_test <- chisq.test(table(data$smoker, data$var1))
Chi_test

# Observed counts
Chi_test$observed


# Fisher exact test


fisher_test <- fisher.test(table(data$smoker, data$hf))

fisher_test


# To perform a squared trend test (also known as a chi-squared test for trend or Cochran-Armitage test for trend

# Is there any significant linear trend between hf and levels on obesity?

table3 <- table(data$hf,data$latestbmi)

CochranArmitageTest(table3)


#================================================================================
#  Task 3 : Explore the following exposure variables:  ethnicity, alcoholmiuse, deprivation, livesalone, carehomes to find out if there
            # an  with CHD
#================================================================================
#=================================================================================
# PROPORTIONS
#=================================================================================


data$chd <- as.factor(data$chd)

data$Ethnicity <- as.factor(data$Ethnicity)
data$quintile <- as.factor(data$quintile)
data$livesalone <- as.factor(data$livesalone)
data$carehome <- as.factor(data$carehome)
data$alcoholmisuse <- as.factor(data$alcoholmisuse)

# carehome

summarytools::ctable(data$carehome, data$chd,prop = 'n', totals = TRUE)


res <- prop.test(x = c(38,568), n = c(362, 49636))
# Printing the results
res

#================================================================================
# ODDS RATIO
#===============================================================================


table <- table(data$carehome, data$chd)

table 


# replace va1= smoker, var2= hf
fit1 <- glm(chd ~ carehome, data=data, family=binomial)
summary(fit1)

coef(fit1) %>% exp()

# Provide some interpretation to your results

confint(fit1) %>% exp()

# method 3. Using fisher test

fisher_test = fisher.test(table)
fisher_test
# How would you interpret adds ratio >  or equal to 2

# alcohol miuse

summarytools::ctable(data$alcoholmisuse, data$chd,prop = 'n', totals = TRUE)


res <- prop.test(x = c(92,514), n = c(6416, 43582))
# Printing the results
res

#================================================================================
# ODDS RATIO
#===============================================================================


table <- table(data$alcoholmisuse, data$chd)

table 


# replace va1= smoker, var2= hf
fit1 <- glm(chd ~ alcoholmisuse, data=data, family=binomial)
summary(fit1)

coef(fit1) %>% exp()

# Provide some interpretation to your results

confint(fit1) %>% exp()

# method 3. Using fisher test

fisher_test = fisher.test(table)
fisher_test
# How would you interpret adds ratio >  or equal to 2

# test for Trend

# Is there any significant linear trend between chd and levels on deprivation

table3 <- table(data$chd, data$quintile)

CochranArmitageTest(table3)





















































